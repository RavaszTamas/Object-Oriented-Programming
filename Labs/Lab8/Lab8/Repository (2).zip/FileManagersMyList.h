#pragma once
#include <string>
#include <vector>
#include "Domain.h"

class FileManagerMyList
{
protected:
	std::string filename;
public:
	FileManagerMyList(std::string newFileName);
	virtual std::vector<Plant> readFile() = 0;
	virtual void saveToFile(Plant elementsToSave) = 0;
	virtual void openFile() = 0;
	virtual ~FileManagerMyList() {};
};

class CsvFileManagerMyList : public FileManagerMyList
{
public:
	CsvFileManagerMyList(std::string newFileName);
	void openFile();
	std::vector<Plant> readFile() override;
	virtual void saveToFile(Plant elementToSave)override;

};

class HTMLFileManagerMyList : public FileManagerMyList
{
private:
	std::string HTMLTableRow(Plant& PlantToConvert);

public:
	HTMLFileManagerMyList(std::string newFileName);
	void openFile();

	std::vector<Plant> readFile() override;
	virtual void saveToFile(Plant elementToSave)override;

};