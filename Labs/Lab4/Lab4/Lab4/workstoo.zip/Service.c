#include "Service.h"
#include "Repository.h"
#include "Domain.h"
#include <malloc.h>
#include <string.h>
#include "validator.h"

int addNewRobot(char* serialNumber, char * state, char * specialization, char* energyCapacity,Robot* RobotRepository,int* lengthOfRobotRepository)
{
	Robot newRobot;
	if(checkIfInteger(serialNumber) == 0)
		return 2;
	newRobot.serialNumber = atoi(serialNumber);
	//newRobot->state = (char*)malloc((strlen(state)+1)*sizeof(char));
	strcpy(newRobot.state,state);
	//->specialization = (char*)malloc((strlen(specialization)+1)*sizeof(char));
	strcpy(newRobot.specialization,specialization);
	if(checkIfInteger(energyCapacity) == 0)
		return 2;

	newRobot.energyCapacity = atoi(energyCapacity);
	return storeNewRobot(newRobot,RobotRepository,lengthOfRobotRepository);
}
 
int updateRobot(char* serialNumber, char * newState, char * newSpecialization, char* newEnergyCapacity, Robot * RobotRepository, int * lengthOfRobotRepository)
{	
	if(checkIfInteger(serialNumber) == 0)
		return 2;

	int serialNumberInteger = atoi(serialNumber);

	if(checkIfInteger(newEnergyCapacity) == 0)
		return 2;

	int newEnergyCapacityInteger = atoi(newEnergyCapacity);

	return updateExistingRobot(serialNumberInteger,newState,newSpecialization,newEnergyCapacityInteger,RobotRepository,lengthOfRobotRepository);
}

int filterRobotsWithSpecialization(char* specialization,int* listofValidIndexes,Robot * RobotRepository, int* lengthOfRobotRepository)
{

	return robotsWithSpecialization(specialization,listofValidIndexes,RobotRepository,lengthOfRobotRepository);
}

int deleteTheRobotFromTheRepository(char* serialNumberToDelete, Robot * RobotRepository, int * lengthOfRobotRepository)
{
	if(checkIfInteger(serialNumberToDelete) == 0)
		return 2;
	int serialNumberToDeleteInteger = atoi(serialNumberToDelete);
	return deleteRobot(serialNumberToDeleteInteger,RobotRepository,lengthOfRobotRepository);
}
