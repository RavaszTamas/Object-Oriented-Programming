#include <stdio.h>
#include <stdlib.h>
#include "UI.h"
//#include "Test.h"

int main()
{
	//testAll();
	UI();
}