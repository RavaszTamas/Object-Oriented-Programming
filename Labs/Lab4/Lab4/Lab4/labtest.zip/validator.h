#pragma once
/*
Checks if a given string is a non negative integer number
input: stringOfCharactersToCheck
output: 0 if it is not an integer
		1 if it is an integer
*/
int checkIfInteger(char* stringOfCharactersToCheck);