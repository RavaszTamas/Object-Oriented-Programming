#pragma once
#include "Repository.h"
#include "Validator.h"
#include <exception>

class AppController
{
private:
	PlantRepository& repositoryOfPlants;
	Validator& validator;
	string mode = "";
	int currentIndexForNextFunctionality = -1;
	DynamicVector<string> listOfChosenPlantClusters;

public:
	AppController operator=(AppController& copyController);
	//AppController(AppController& copyController);
	AppController(PlantRepository& plantRepository, Validator& validator);

	
	//Sets the mode the given modeToSet, if the mode is not valid an exception is thrown using the validator
	void SetMode(string& modeToSet);

	/*

	*/
	void AddNewPlant(string& newCodeName, string& newSpecies, int newAgeInMonths, string& newDigitizedScan);

	void UpdatePlant(string& newCodeName, string& newSpecies, int newAgeInMonths, string& newDigitizedScan);

	void DeletePlant(string& codeNameToDeleteBy);

	void saveToUprootList(string& codeNameToAddBy);

	const Plant& getCurrentPlantByNext();

	DynamicVector<Plant> displayChosenPlantClusters();

	DynamicVector<Plant> displayPlantClutersByAgeAndSpecies(string& species, int ageInMonths);

	DynamicVector<Plant>& listAll();

};
