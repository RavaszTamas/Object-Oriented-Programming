#pragma once
#include "Domain.h"
#include "DynamicArray.h"

void UIFilterSpecialization(char* specialization,DynamicVector* RobotRepository);

void UIListRobots(char* inputParameters,DynamicVector* RobotRepository);

void UIDeleteRobot(char* serialNumber,DynamicVector* RobotRepository, DynamicVector* UndoRedoStackOfVectors);

void UIUpdateExistingRobot(char* inputParameters,DynamicVector* RobotRepository, DynamicVector* UndoRedoStackOfVectors);

void UIAddNewRobot(char* inputParameters,DynamicVector* RobotRepository,DynamicVector* UndoRedoStackOfVectors);

void UIFilterByMaxEnergyCapacity(int maxEnegryCapacity,DynamicVector* RobotRepository);

void UIUndo(DynamicVector* RobotRepository, DynamicVector* UndoRedoStack);

void UIRedo();

DynamicVector* UIUndoListofLists(DynamicVector* RobotRepository, DynamicVector* UndoRedoStackOfVectors);

DynamicVector* UIUndoListofLists(DynamicVector* RobotRepository, DynamicVector* UndoRedoStackOfVectors);


void UI();