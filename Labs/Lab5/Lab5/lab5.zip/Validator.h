#pragma once
#include <iostream>
#include <vector>

using namespace std;
class Validator
{
	vector<string> modes = { "A" };
public:
	bool ValidateInteger(int integerToValidate);

	bool ValidateMode(string& modeToCheck);
};