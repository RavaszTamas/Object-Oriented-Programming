#pragma once
#include "DynamicArray.h"
#include "Domain.h"
using namespace std;

class PlantRepository
{
private:
	DynamicVector<Plant> listOfPlants;
public:
	
	PlantRepository& operator=(PlantRepository& copyRepository);
	PlantRepository(PlantRepository& copyRepository);
	PlantRepository();

	int findIndexOfElement(string& codeNameToFind);

	void storeNewPlant(Plant& newPlantToStore);

	void updatePlant(Plant& plantToUpdateWith);

	void removePlant(string& codeNameToRemove);

	DynamicVector<Plant>& listAllElements();
};

