#pragma once
#include <iostream>
using namespace std;

class Plant
{
private:
	string codeName;
	string species;
	int ageInMonths;
	int stuff;
	string digitizedScan;
public:

	Plant(string newCodeName, string newSpecies, int newAgeInMonths, string newDigitizedScan);
	Plant& operator=(Plant& copyPlant);
	Plant();
	
	string& getCodeName();
	string& getSpecies();
	int getAgeInMonths();
	string& getDigitizedScan();

	void setCodeName(string newCodeName);
	void setSpecies(string newSpecies);
	void setAgeInMonths(int newAgeInMonths);
	void setDigitizedScan(string newDigitizedScan);

};