#pragma once
#include "Domain.h"

template <typename T>
class DynamicVector
{
private:
	T* elements;
	int size;
	int capacity;

public:
	// default constructor for a DynamicVector
	DynamicVector();

	// copy constructor for a DynamicVector
	DynamicVector(const DynamicVector& vector);
	~DynamicVector();

	// assignment operator for a DynamicVector
	DynamicVector& operator=(const DynamicVector& vector);

	/*
	Overloading the subscript operator
	Input: pos - a valid position within the vector.
	Output: a reference to the element o position pos.
	*/
	T& operator[](int position);

	// Adds an element to the current DynamicVector.
	void add(T newElement);

	void remove(int indexToRemove);

	void update(int indexToUpdate, T&);

	int getSize() const;

private:
	// Resizes the current DynamicVector, multiplying its capacity by a given factor (real number).
	void resize(double factor = 2);
};

template <typename T>
DynamicVector<T>::DynamicVector()
{
	this->size = 0;
	int capacity = 10;
	if (capacity <= 0)
		capacity = 10;
	this->capacity = capacity;
	this->elements = new T[capacity];
}

template<typename T>
DynamicVector<T>::DynamicVector(const DynamicVector & vector)
{
	this->size = vector.size;
	this->capacity = vector.capacity;
	this->elements = new T[this->capacity];
	for (int i = 0; i < this->size; i++)
		this->elements[i] = vector.elements[i];
}

template<typename T>
DynamicVector<T>::~DynamicVector()
{
	delete[] this->elements;

}

template<typename T>
DynamicVector<T> & DynamicVector<T>::operator=(const DynamicVector & vector)
{
	this->size = vector.size;
	this->capacity = vector.capacity;

	T* auxilliaryArray = new T[this->capacity];

	delete[] this->elements;


	this->elements = auxilliaryArray;

	for (int i = 0; i < this->size; ++i)
	{
		this->elements[i] = vector.elements[i];
	}

	return *this;
}


template<typename T>
T & DynamicVector<T>::operator[](int position)
{
	return this->elements[position];
}

template<typename T>
void DynamicVector<T>::add(T newElement)
{
	if (this->size == this->capacity)
		this->resize();
	this->elements[this->size++] = newElement;

}

template<typename T>
void DynamicVector<T>::remove(int indexToRemove)
{
	if (indexToRemove < 0)
		throw "Invalid index!";

	for (int i = indexToRemove; i < this->size; ++i)
		this->elements[i] = this->elements[i + 1];
	this->size--;
}

template<typename T>
inline void DynamicVector<T>::update(int indexToUpdate, T & elementToUpdateWith)
{
	if (indexToUpdate < 0)
		throw "Invalid index";
	this->elements[indexToUpdate] = elementToUpdateWith;
}

template<typename T>
int DynamicVector<T>::getSize() const
{
	return this ->size;
}

template<typename T>
void DynamicVector<T>::resize(double factor)
{
	this->capacity *= factor;

	T* newElements = new T[this->capacity];
	for (int i = 0; i < this->size; i++)
		newElements[i] = this->elements[i];

	delete[] this->elements;
	this->elements = newElements;

}

