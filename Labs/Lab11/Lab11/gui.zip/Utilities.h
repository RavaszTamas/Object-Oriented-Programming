#pragma once
#include <iostream>
#include <vector>

bool CheckIfAllDigits(std::string& stringtToCheck);

std::vector<std::string> tokenize(const std::string& str, char delimiter);

std::string getExtention(std::string input);