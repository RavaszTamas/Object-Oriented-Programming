#include "gui.h"
#include <QtWidgets/QApplication>
#include "TextFileRepo.h"
#include "Service.h"

int main(int argc, char *argv[])
{
	PlantFileRepository repository;
	Validator validator;
	AppController controller{ repository, validator };

	QApplication a(argc, argv);
	PlantsGUI gui{ controller };
	gui.show();
	return a.exec();
}
