#pragma once

#include <QtWidgets/QMainWindow>
#include "ui_Lab11.h"
#include <qwidget.h>
#include <QListWidget>
#include <QFormLayout>
#include <QLineEdit>
#include <QTextEdit>
#include <QPushButton>
#include <QLabel>
#include "Domain.h"
#include "Service.h"

class PlantsGUI : public QMainWindow
{
	Q_OBJECT

public:
	PlantsGUI(AppController& _paramController,QWidget *parent = 0);
	~PlantsGUI();

	QListWidget* plantList;
	QListWidget* uprootPlantList;
	QLineEdit* codeNameEdit;
	QLineEdit* speciesEdit;
	QLineEdit* ageInMonthEdit;
	QLineEdit* digitizedScanEdit;
	QPushButton* addPlantButton;
	QPushButton* removePlantButton;
	QPushButton* updatePlantButton;
	QPushButton* filterPlantsButton;
	QPushButton* saveToUprootListButton;
	QPushButton* openUprootListButton;

	void buildWindow();

	void connectSignalsAndSlots();

	void populatePlantsList();

	void populateUprootList();

	void populatePlantsListWithVector(std::vector<Plant> plants);

	void listItemChanged();

	int getSelectedIndex();

	void addPlantButtonHandler();

	void removePlantButonHandler();

	void updatePlantButtonHandler();

	void filterPlantsButtonHandler();

	void saveToUprootListButtonHandler();

	void openUprootListHandler();

	bool verifyNoSpaces();

signals:
	void plantsUpdateSignal();
	void uprootUpdateSignal();

	void RemovePlantSignal(const std::string& codeName);
	void AddPlantSignal(const std::string& codeName, const std::string& species, const int ageInMonths, const std::string& digitizedScan);
	void UpdatePlantSignal(const std::string& codeName, const std::string& species, const int ageInMonths, const std::string& digitizedScan);
	void SaveToUprootListSignal(const std::string& codeName);
	void FilterPlantsSignal(const std::string& species, const int ageInMonths);

public slots:
	void AddPlant(const std::string& plantCodeName, const std::string& species, const int ageInMonths, const std::string& digitizedScan);
	void RemovePlant(const std::string& plantCodeName);
	void UpdatePlant(const std::string& plantCodeName, const std::string& species, const int ageInMonths, const std::string& digitizedScan);
	void SaveToUprootList(const std::string& codeName);
	void FilterPlants(const std::string& species, const int ageInMonths);

private:
	AppController& controller;
	Ui::Lab11Class ui;
};
